package com.otp.ejb;

import javax.ejb.Local;

@Local
public interface OTPSessionBeanLocal {

}
